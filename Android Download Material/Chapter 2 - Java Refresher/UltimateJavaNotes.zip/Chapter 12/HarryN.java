package codewithharry;

public class HarryN {
    public static void main(String[] args) {
        System.out.println("I am class harry n's main method!");
    }
}
